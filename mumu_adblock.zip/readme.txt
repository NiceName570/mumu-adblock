Double-click mumu_adblock.exe → blocks MuMu Player ads (elevated).
Add a .txt readme if needed.